#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

typedef struct piece 
{
    unsigned int position : 7;
    unsigned int color : 1;
    unsigned int type : 3;
    unsigned int moved : 1;

}piece_t;



    


