#include "chess.h"

int piece_get_x(piece_t* p);
int piece_get_y(piece_t* p);
int piece_move(piece_t* p);
int rook_pattern(int pos_x,int pos_y, int x, int y);