#include "chessboard.h"

piece_t** board_alloc()
{
    piece_t** pieces = malloc(sizeof(piece_t)*32);       
    for(int i = 0; i<32; i++){
          pieces[i] = malloc(sizeof(piece_t));
   }
   return pieces;
}


void board_free(piece_t** board)
{
    for(int i = 0; i<32; i++){
        free(board[i]);
    }
    free(board);
}