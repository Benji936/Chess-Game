#include "piece.h"

int piece_get_x(piece_t* p)
{
    return p->position%8+1;
}

int piece_get_y(piece_t* p)
{
    return p->position/8+1;
}

int piece_pattern(piece_t* piece, int x, int y){
    switch (piece->type)
    {
        case 0:
            if(piece->moved){
                return abs(y-piece_get_y(piece)) == 1 && (-2 < piece_get_x(piece)-x < 2);
            }
            else{
                 return 0 < abs(y-piece_get_y(piece)) < 3 && (-2 < piece_get_x(piece)-x < 2);
            }
            break;
        case 1:
            return (abs(piece_get_x(piece)-x) + abs(piece_get_y(piece)-y)) == 3 && (x != piece_get_x(piece) && y != piece_get_y(piece));
            break;
        case 2:
            return abs(piece_get_x(piece)-x) - abs(piece_get_y(piece)-y);
            break;
        case 3:
            return (piece_get_x(piece) == x || piece_get_y(piece) == y);
            break;
        case 4:
            return (piece_get_y(piece) == y || piece_get_x(piece) ==x) || (abs(piece_get_x(piece)-x) - abs(piece_get_y(piece)-y) == 0);
            break;
        case 5:
            return (abs(piece_get_y(piece) - y) < 2 && abs(piece_get_x(piece) - x) < 2); 
            break;
    }
}

int piece_move(piece_t* p)
{
    return 0;
}

