#include "chessboard.h"
#include <string.h>
#include <ctype.h>

int abs(int number)
{
       if(number >= 0) return number;
       else return -number;
}

int match_color(char p){
       if(tolower(p) == p) return 1;
       else return 0;
}

int match_piece(char p){
       switch (tolower(p))
       {
              case 'p':
                     return 0;
                     break;
              case 'n':
                     return 1;
                     break;
              case 'b':
                     return 2;
                     break;
              case 'r':
                     return 3;
                     break;
              case 'q':
                     return 4;
                     break;
              case 'k':
                     return 5;
                     break;                     
       }
}

void convert_string_in_board(piece_t** pieces,char* string)
{
       int x = 0;
       int y = 0;
       int val = 0;
       int j = 0;
       for(int i = 0; i<strlen(string); i++){
              char n = string[i];
              val = atoi(&n);
              
              if(val) x+= val;
              else if(string[i]=='/'){
                     y+=1;
                     x=0;
              }
              else{
                     pieces[j]->position = x+y*8;
                     pieces[j]->color = match_color(string[i]);
                     pieces[j]->type = match_piece(string[i]); 
                     j+=1;
                     x+=1;
              }
       }

}

int main()
{
       piece_t** pieces = board_alloc();
       
       convert_string_in_board(pieces,"RNBQKBNR/PPPPPPPP/////pppppppp/rnbqkbnr");
       for(int i = 0; i<32; i++){
              printf("%d\n",pieces[i]->type);
       }
       printf("FIN\n");

       board_free(pieces);
}