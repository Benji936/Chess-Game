int abs(int number);
void convert_string_in_board(piece_t** pieces,char* string);