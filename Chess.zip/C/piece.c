#include "piece.h"

int piece_get_x(int index)
{
    return index%8;
}

int piece_get_y(int index)
{
    return index/8;
}

int piece_pattern(piece_t* piece, int index, int x, int y){
    switch (piece->type)
    {
        case 0:
            printf("%d\n",abs(piece_get_x(index)-x));
            if(piece->moved){
                return (abs(y-piece_get_y(index)) < 2 && (abs(piece_get_x(index)-x) < 2));
            }
            else{
                return (abs(y-piece_get_y(index)) < 3 && (abs(piece_get_x(index)-x) < 2));
            }
        case 1:
            return (abs(piece_get_x(index)-x) + abs(piece_get_y(index)-y)) == 3 && (x != piece_get_x(index) && y != piece_get_y(index));
        case 2:
            return abs(piece_get_x(index)-x) - abs(piece_get_y(index)-y);
        case 3:
            return (piece_get_x(index) == x || piece_get_y(index) == y);
        case 4:
            return (piece_get_y(index) == y || piece_get_x(index) ==x) || (abs(piece_get_x(index)-x) - abs(piece_get_y(index)-y) == 0);
        case 5:
            return (abs(piece_get_y(index) - y) < 2 && abs(piece_get_x(index) - x) < 2); 
    }
}


piece_t* piece_copy(piece_t* p)
{
    piece_t* piece = malloc(sizeof(piece_t));
    piece_t copy = *p;
    piece->position = copy.position;
    piece->color = copy.color;
    piece->moved = copy.moved;
    piece->type = copy.type;
    return piece;
}

int piece_move(piece_t** board, int x, int y,int index)
{
    if(x+y*8 > 64) return -1;
    if(!piece_pattern(board[index],index,x,y)) return -1;


    free(board[x+y*8]);
    board[x+y*8] = piece_copy(board[index]);
    board[x+y*8]->moved = 1;
    board[index]->position = 0;
    return 0;
}

