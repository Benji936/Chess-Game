#include "chessboard.h"

piece_t** board_alloc()
{
    piece_t** pieces = malloc(sizeof(piece_t)*64);       
    for(int i = 0; i<64; i++){
          pieces[i] = malloc(sizeof(piece_t));
          pieces[i]->color = 0;
          pieces[i]->type = 0;
          pieces[i]->moved = 0;
          pieces[i]->position = 0;
   }
   return pieces;
}

void board_free(piece_t** board)
{
    for(int i = 0; i<64; i++){
        free(board[i]);
    }
    free(board);
}

piece_t** board_copy(piece_t** board)
{
    piece_t** pieces = malloc(sizeof(piece_t)*64);       
    for(int i = 0; i<64; i++){
       pieces[i] = piece_copy(board[i]);
        
    }
    return pieces;
}