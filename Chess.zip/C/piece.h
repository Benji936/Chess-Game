#include "chess.h"

int piece_get_x(int index);
int piece_get_y(int index);
int piece_move(piece_t** board, int x, int y,int index);
int piece_pattern(piece_t* piece, int index, int x, int y);
piece_t* piece_copy(piece_t* p);