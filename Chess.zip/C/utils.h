int abs(int number);
