#include "piece.h"

piece_t** board_alloc();
void board_free(piece_t** board);
piece_t** board_copy(piece_t** board);