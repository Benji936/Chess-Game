#include "chessboard.h"
#include <string.h>
#include <ctype.h>

int abs(int number)
{
       if(number >= 0) return number;
       else return -number;
}

//Fonction qui détermine la couleur à partir d'un caractère (Majuscule = Noir, Minuscule = Blanc)
int match_color(char p){
       if(tolower(p) == p) return 1;
       else return 0;
}

int match_piece(char p){
       switch (tolower(p))
       {
              case 'p':
                     return 0;
              case 'n':
                     return 1;
              case 'b':
                     return 2;
              case 'r':
                     return 3;
              case 'q':
                     return 4;
              case 'k':
                     return 5;
              default:
                     return -1;                     
       }
}

void print_board(piece_t** board)
{
       for(int i = 0; i<64; i++){
              if(board[i]->position == 0){
                     printf("-");
              }
              else{
                     printf("%d",board[i]->type);
              } 

              if((i+1)%8 == 0){
                     printf("\n");
              }
       }
}

void convert_string_in_board(piece_t** pieces,char* string)
{
       int x = 0;
       int y = 0;
       int val = 0;
       for(int i = 0; i<strlen(string); i++){
              char n = string[i];
              val = atoi(&n);
              
              if(val) x+= val;
              else if(string[i]=='/'){
                     y+=1;
                     x=0;
              }
              else if(match_piece(string[i]) > -1){
                     pieces[x+y*8]->position = 1;
                     pieces[x+y*8]->color = match_color(string[i]);
                     pieces[x+y*8]->type = match_piece(string[i]); 
                     x+=1;
              }
       }
}

int main()
{
       piece_t** pieces = board_alloc();
       
       convert_string_in_board(pieces,"RNBQKBNR/PPPPPPPP/////pppppppp/rnbqkbnr");
       print_board(pieces);

       piece_move(pieces,7,4,55);

       print_board(pieces);

       piece_move(pieces,7,2,39);
       print_board(pieces);

       board_free(pieces);
}